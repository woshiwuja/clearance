create table shortened_urls (
  id text primary key,
  url text not null
);